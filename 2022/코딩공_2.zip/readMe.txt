실행 명령어 
python problemP2.py --json ./answer.json

상위폴더 코딩공.json으로 결과를 덮어쓰고 싶을 경우 :
python problemP2.py --json ../코딩공.json

인자 설명
--json : json 출력 경로 (주의! 기존 json이 없으면 안됨 / 문장 데이터가 있는 파일로 설정 덮어 쓰기 된다.)